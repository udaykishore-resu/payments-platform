###############################################################################
# envs/staging/terraform.tfvars
###############################################################################

environment = "staging"

owner       = "platform-payments"
cost_centre = "CC-4712"

# Synthetic data only. There is no anonymisation pipeline and no scrubbed
# production dump - deployment.md 6.1 is unambiguous about why.
data_classification = "internal"
compliance_scope    = "pci-dss-out-of-scope"

region             = "eu-west-1"
vpc_cidr           = "10.30.0.0/16"
availability_zones = ["eu-west-1a", "eu-west-1b", "eu-west-1c"]

subnets = {
  public    = ["10.30.0.0/22", "10.30.4.0/22", "10.30.8.0/22"]
  pod       = ["10.30.16.0/20", "10.30.80.0/20", "10.30.96.0/20"]
  data      = ["10.30.32.0/22", "10.30.36.0/22", "10.30.40.0/22"]
  streaming = ["10.30.48.0/22", "10.30.52.0/22", "10.30.56.0/22"]
  egress    = ["10.30.64.0/22", "10.30.68.0/22", "10.30.72.0/22"]
  firewall  = ["10.30.112.0/28", "10.30.112.16/28", "10.30.112.32/28"]
}

# Sandbox endpoints, never live ones. A staging credential that could reach a
# live gateway is a staging credential that can move real money.
egress_allowlist_domains = [
  "api.sandbox.stripe.com",
  ".adyen.com",
  "api-m.sandbox.paypal.com",
  "sandbox.kyc-vendor.example",
  "sandbox.bank-validation.example",
  "idp.example.com",
]

# Staging upgrades first, one minor at a time. When this is ahead of prod, that
# is the intended state and the difference is tracked in the upgrade ticket.
kubernetes_version = "1.30"

eks_addon_versions = {
  vpc_cni            = "v1.18.3-eksbuild.2"
  coredns            = "v1.11.1-eksbuild.9"
  kube_proxy         = "v1.30.0-eksbuild.3"
  ebs_csi            = "v1.32.0-eksbuild.1"
  pod_identity_agent = "v1.3.0-eksbuild.1"
}

# Same taints and labels as prod - a workload that schedules in staging must
# schedule in prod. Smaller instances and lower floors; the shape is identical.
node_groups = {
  data = {
    instance_types = ["c7g.xlarge", "c7g.2xlarge"]
    capacity_type  = "ON_DEMAND"
    min_size       = 3
    max_size       = 12
    desired_size   = 3
    labels         = { "pp.plane" = "data" }
    taints = [
      { key = "pp.plane", value = "data", effect = "NO_SCHEDULE" },
    ]
  }

  control = {
    instance_types = ["m7g.large", "m7g.xlarge"]
    capacity_type  = "ON_DEMAND"
    min_size       = 2
    max_size       = 8
    desired_size   = 2
    labels         = { "pp.plane" = "control" }
    taints = [
      { key = "pp.plane", value = "control", effect = "NO_SCHEDULE" },
    ]
  }

  general = {
    instance_types = ["m7g.large", "m7g.xlarge"]
    capacity_type  = "SPOT"
    min_size       = 2
    max_size       = 8
    desired_size   = 3
    labels         = { "pp.plane" = "general" }
    taints         = []
  }
}

eks_public_access_cidrs = ["203.0.113.0/28"]

eks_access_entries = {
  developers = {
    principal_arn     = "arn:aws:iam::222233334444:role/pp-human-developer"
    policy_arn        = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSViewPolicy"
    access_scope_type = "cluster"
  }
  sre = {
    principal_arn     = "arn:aws:iam::222233334444:role/pp-human-sre"
    policy_arn        = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSAdminPolicy"
    access_scope_type = "cluster"
  }
  argocd = {
    principal_arn     = "arn:aws:iam::222233334444:role/pp-argocd-deployer"
    policy_arn        = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSAdminPolicy"
    access_scope_type = "namespace"
    namespaces        = ["pp-data-plane", "pp-control-plane", "pp-automation", "pp-platform", "pp-observability"]
  }
}

# Engine versions match prod exactly. This is the whole point of staging.
aurora_engine_version        = "15.5"
aurora_instance_class        = "db.r6g.large"
aurora_backup_retention_days = 7

msk_kafka_version        = "3.6.0"
msk_broker_instance_type = "kafka.m5.large"

redis_node_type = "cache.r7g.large"

zone_name       = "example.com"
api_hostname    = "api.staging.example.com"
route53_zone_id = "Z0123456789ABCDEFGHIJ"

alert_topic_subscriptions = {
  https = "https://events.pagerduty.com/integration/PLACEHOLDER-STAGING/enqueue"
}

budget_monthly_usd         = 6000
budget_notification_emails = ["platform-payments@example.com"]

key_administrator_arns = [
  "arn:aws:iam::222233334444:role/pp-terraform-staging",
]
