###############################################################################
# envs/prod/terraform.tfvars
#
# The values in this file are reviewed as carefully as the code. A wrong number
# here is not caught by `terraform validate` - it is caught by a validation
# block, a check block, or by production.
###############################################################################

environment = "prod"

# --- Tagging ------------------------------------------------------------------
owner       = "platform-payments"
cost_centre = "CC-4711"

# The production estate holds real payment metadata, merchant PII and KYC
# evidence. It holds no cardholder data (baseline A2), which is why the scope is
# service-provider rather than CDE.
data_classification = "restricted"
compliance_scope    = "pci-dss-service-provider"

# --- Regions ------------------------------------------------------------------
primary_region = "eu-west-1"
dr_region      = "eu-central-1"

primary_vpc_cidr           = "10.20.0.0/16"
dr_vpc_cidr                = "10.21.0.0/16"
primary_availability_zones = ["eu-west-1a", "eu-west-1b", "eu-west-1c"]
dr_availability_zones      = ["eu-central-1a", "eu-central-1b", "eu-central-1c"]

# deployment.md 2.2. Pod subnets are /20 because the VPC CNI assigns real VPC
# IPs per pod: 400 pods per AZ with prefix delegation consumes address space
# fast, and CNI IP exhaustion during a scale-up is an outage that presents as a
# scheduling problem.
primary_subnets = {
  public    = ["10.20.0.0/22", "10.20.4.0/22", "10.20.8.0/22"]
  pod       = ["10.20.16.0/20", "10.20.80.0/20", "10.20.96.0/20"]
  data      = ["10.20.32.0/22", "10.20.36.0/22", "10.20.40.0/22"]
  streaming = ["10.20.48.0/22", "10.20.52.0/22", "10.20.56.0/22"]
  egress    = ["10.20.64.0/22", "10.20.68.0/22", "10.20.72.0/22"]
  firewall  = ["10.20.112.0/28", "10.20.112.16/28", "10.20.112.32/28"]
}

dr_subnets = {
  public    = ["10.21.0.0/22", "10.21.4.0/22", "10.21.8.0/22"]
  pod       = ["10.21.16.0/20", "10.21.80.0/20", "10.21.96.0/20"]
  data      = ["10.21.32.0/22", "10.21.36.0/22", "10.21.40.0/22"]
  streaming = ["10.21.48.0/22", "10.21.52.0/22", "10.21.56.0/22"]
  egress    = ["10.21.64.0/22", "10.21.68.0/22", "10.21.72.0/22"]
  firewall  = ["10.21.112.0/28", "10.21.112.16/28", "10.21.112.32/28"]
}

# security.md 2.2. Every destination the platform is permitted to reach. Adding
# one is a reviewed PR, never a runtime decision - and the review question is
# "which service account needs this, and why can it not use a VPC endpoint".
egress_allowlist_domains = [
  "api.stripe.com",
  ".adyen.com",
  "api-m.paypal.com",
  "api.kyc-vendor.example",
  "api.bank-validation.example",
  "idp.example.com",
]

# --- EKS ----------------------------------------------------------------------
# N-1 of the latest EKS release, upgraded quarterly, staging first, one minor at
# a time (deployment.md 2.3).
kubernetes_version = "1.30"

eks_addon_versions = {
  vpc_cni            = "v1.18.3-eksbuild.2"
  coredns            = "v1.11.1-eksbuild.9"
  kube_proxy         = "v1.30.0-eksbuild.3"
  ebs_csi            = "v1.32.0-eksbuild.1"
  pod_identity_agent = "v1.3.0-eksbuild.1"
}

# Taints and labels here MUST match the nodeSelector and tolerations in
# deployment.md 1.2. A mismatch is silent: pods stay Pending and nothing
# explains why.
#
# Sizing: the `data` floor is three AZs' worth of capacity such that any two AZs
# carry 100% of peak (3x headroom). That is the number the AZ-loss survival
# claim rests on, not a cost optimum.
node_groups = {
  primary = {
    data = {
      instance_types = ["c7g.4xlarge", "c7g.8xlarge"]
      capacity_type  = "ON_DEMAND" # The money path does not tolerate Spot interruption.
      min_size       = 9
      max_size       = 60
      desired_size   = 12
      disk_size_gb   = 200
      ami_type       = "AL2023_ARM_64_STANDARD"
      labels         = { "pp.plane" = "data" }
      taints = [
        { key = "pp.plane", value = "data", effect = "NO_SCHEDULE" },
      ]
      max_unavailable_percentage = 10
    }

    control = {
      instance_types = ["m7g.2xlarge"]
      capacity_type  = "ON_DEMAND"
      min_size       = 3
      max_size       = 18
      desired_size   = 6
      labels         = { "pp.plane" = "control" }
      taints = [
        { key = "pp.plane", value = "control", effect = "NO_SCHEDULE" },
      ]
      max_unavailable_percentage = 25
    }

    general = {
      instance_types = ["m7g.xlarge", "m7g.2xlarge"]
      capacity_type  = "SPOT" # Platform and observability tolerate interruption; the money path does not.
      min_size       = 3
      max_size       = 15
      desired_size   = 4
      labels         = { "pp.plane" = "general" }
      taints         = []
    }
  }

  # The warm-passive floor: roughly 10% of the primary's compute. Cold passive
  # was measured at 4-6 minutes added to the RTO for image pull, JIT warm-up,
  # connection-pool establishment and JWKS fetch (disaster-recovery.md 2.2).
  dr = {
    data = {
      instance_types = ["c7g.4xlarge", "c7g.8xlarge"]
      capacity_type  = "ON_DEMAND"
      min_size       = 3
      max_size       = 60
      desired_size   = 3
      disk_size_gb   = 200
      ami_type       = "AL2023_ARM_64_STANDARD"
      labels         = { "pp.plane" = "data" }
      taints = [
        { key = "pp.plane", value = "data", effect = "NO_SCHEDULE" },
      ]
      max_unavailable_percentage = 10
    }

    control = {
      instance_types = ["m7g.2xlarge"]
      capacity_type  = "ON_DEMAND"
      min_size       = 2
      max_size       = 18
      desired_size   = 2
      labels         = { "pp.plane" = "control" }
      taints = [
        { key = "pp.plane", value = "control", effect = "NO_SCHEDULE" },
      ]
    }

    general = {
      instance_types = ["m7g.xlarge"]
      capacity_type  = "SPOT"
      min_size       = 2
      max_size       = 10
      desired_size   = 2
      labels         = { "pp.plane" = "general" }
      taints         = []
    }
  }
}

# The CI runners' NAT addresses and the break-glass bastion. Never 0.0.0.0/0 -
# the module rejects it outright.
eks_public_access_cidrs = [
  "203.0.113.0/28",
  "198.51.100.16/29",
]

eks_access_entries = {
  sre = {
    principal_arn     = "arn:aws:iam::111122223333:role/pp-human-sre"
    policy_arn        = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSViewPolicy"
    access_scope_type = "cluster"
  }
  argocd = {
    principal_arn     = "arn:aws:iam::111122223333:role/pp-argocd-deployer"
    policy_arn        = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSAdminPolicy"
    access_scope_type = "namespace"
    namespaces        = ["pp-data-plane", "pp-control-plane", "pp-automation", "pp-platform", "pp-observability"]
  }
}

# --- Aurora -------------------------------------------------------------------
aurora_engine_version        = "15.5"
aurora_instance_class        = "db.r6g.4xlarge"
aurora_dr_instance_class     = "db.r6g.2xlarge" # Half class, deliberately. See variables.tf.
aurora_backup_retention_days = 35

# --- MSK ----------------------------------------------------------------------
msk_kafka_version        = "3.6.0"
msk_broker_instance_type = "kafka.m5.2xlarge"
msk_broker_ebs_gb        = 2000

# --- ElastiCache --------------------------------------------------------------
redis_node_type = "cache.r7g.large"
redis_shards    = 3

# --- Edge and DNS -------------------------------------------------------------
zone_name       = "example.com"
api_hostname    = "api.example.com"
route53_zone_id = "Z0123456789ABCDEFGHIJ"

blocked_country_codes  = ["KP", "IR", "SY", "CU"]
enable_shield_advanced = true

# --- Observability and cost ---------------------------------------------------
alert_topic_subscriptions = {
  https = "https://events.pagerduty.com/integration/PLACEHOLDER/enqueue"
}

budget_monthly_usd         = 50000
budget_notification_emails = ["platform-payments@example.com"]

grafana_sso_admin_group_ids = ["e4f8a1c2-0000-4000-8000-000000000001"]

# --- IAM ----------------------------------------------------------------------
key_administrator_arns = [
  "arn:aws:iam::111122223333:role/pp-terraform-prod",
  "arn:aws:iam::111122223333:role/pp-break-glass-kms",
]

backup_vault_account_arn = "arn:aws:backup:eu-west-1:444455556666:backup-vault:pp-prod-offsite"

# Rotation lambda packages are published by CI. Left empty until they are, which
# is the correct state - an empty map creates the IAM surface and no functions.
rotation_lambda_artifact_bucket = ""
rotation_lambda_artifacts       = {}
