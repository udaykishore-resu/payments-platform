###############################################################################
# envs/dev/terraform.tfvars
###############################################################################

environment = "dev"

owner       = "platform-payments"
cost_centre = "CC-4713"

data_classification = "internal"
compliance_scope    = "pci-dss-out-of-scope"

region             = "eu-west-1"
vpc_cidr           = "10.40.0.0/16"
availability_zones = ["eu-west-1a", "eu-west-1b", "eu-west-1c"]

subnets = {
  public    = ["10.40.0.0/22", "10.40.4.0/22", "10.40.8.0/22"]
  pod       = ["10.40.16.0/20", "10.40.80.0/20", "10.40.96.0/20"]
  data      = ["10.40.32.0/22", "10.40.36.0/22", "10.40.40.0/22"]
  streaming = ["10.40.48.0/22", "10.40.52.0/22", "10.40.56.0/22"]
  egress    = ["10.40.64.0/22", "10.40.68.0/22", "10.40.72.0/22"]
  firewall  = ["10.40.112.0/28", "10.40.112.16/28", "10.40.112.32/28"]
}

# The gateway simulator only. Dev holds no sandbox credentials at all: a preview
# environment is the least-controlled compute in the estate (deployment.md 6.2),
# and a credential that reaches it is a credential that has left the building.
egress_allowlist_domains = [
  "idp.example.com",
]

single_nat_gateway      = true
enable_network_firewall = false

kubernetes_version = "1.30"

eks_addon_versions = {
  vpc_cni            = "v1.18.3-eksbuild.2"
  coredns            = "v1.11.1-eksbuild.9"
  kube_proxy         = "v1.30.0-eksbuild.3"
  ebs_csi            = "v1.32.0-eksbuild.1"
  pod_identity_agent = "v1.3.0-eksbuild.1"
}

# Spot-first everywhere including the data group. Dev has no availability
# target, and Spot interruption is a useful thing for developers to see happen
# occasionally.
node_groups = {
  data = {
    instance_types = ["c7g.large", "c7g.xlarge", "c6g.large"]
    capacity_type  = "SPOT"
    min_size       = 1
    max_size       = 6
    desired_size   = 2
    labels         = { "pp.plane" = "data" }
    taints = [
      { key = "pp.plane", value = "data", effect = "NO_SCHEDULE" },
    ]
  }

  control = {
    instance_types = ["m7g.large", "m6g.large"]
    capacity_type  = "SPOT"
    min_size       = 1
    max_size       = 4
    desired_size   = 1
    labels         = { "pp.plane" = "control" }
    taints = [
      { key = "pp.plane", value = "control", effect = "NO_SCHEDULE" },
    ]
  }

  general = {
    instance_types = ["m7g.large", "m6g.large", "m7g.xlarge"]
    capacity_type  = "SPOT"
    min_size       = 2
    max_size       = 12
    desired_size   = 3
    labels         = { "pp.plane" = "general" }
    taints         = []
  }
}

eks_public_access_cidrs = ["203.0.113.0/28", "198.51.100.0/24"]

eks_access_entries = {
  developers = {
    principal_arn     = "arn:aws:iam::333344445555:role/pp-human-developer"
    policy_arn        = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSAdminPolicy"
    access_scope_type = "cluster"
  }
  argocd = {
    principal_arn     = "arn:aws:iam::333344445555:role/pp-argocd-deployer"
    policy_arn        = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy"
    access_scope_type = "cluster"
  }
}

# Same engine version as prod. A dev cluster on a different version finds
# different bugs, which is worse than finding none.
aurora_engine_version     = "15.5"
aurora_serverless_min_acu = 0.5
aurora_serverless_max_acu = 4

msk_kafka_version = "3.6.0"

redis_node_type = "cache.t4g.micro"

zone_name       = "example.com"
api_hostname    = "api.dev.example.com"
route53_zone_id = "Z0123456789ABCDEFGHIJ"

# Slack, not PagerDuty. Paging on a dev alert is how a team learns to ignore
# pages.
alert_topic_subscriptions = {}

budget_monthly_usd         = 2500
budget_notification_emails = ["platform-payments@example.com"]

key_administrator_arns = [
  "arn:aws:iam::333344445555:role/pp-terraform-dev",
]
